<html>

    <head>
        <title>Thank You</title>
        <style>
            p{

                font-size:22px;
            }
        </style>
    </head>

    <body>
        <center>
            <p style="margin-top: 150px;"><b>Thank You for Purchasing from GiftMania.</b></p>
            <p><a href="indexnwer.php"><b>Click here</a> to go back to the Home page.</b></p>
        </center>
    </body>
</html>